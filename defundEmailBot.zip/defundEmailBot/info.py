# ********** INFO TO CHANGE **********
# make sure each input is surrounded by " "
FIRST_NAME = "Jane" 
LAST_NAME = "Doe"
YOUR_EMAIL_ADDRESS = "myemail@gmail.com"
YOUR_EMAIL_PASSWORD = "mypassword"
# ********** INFO TO CHANGE **********

