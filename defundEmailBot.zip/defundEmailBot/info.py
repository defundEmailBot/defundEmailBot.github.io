# ********** INFO TO CHANGE **********
# make sure each input is surrounded by " "

FIRST_NAME = "firstName"
LAST_NAME = "lastName"
YOUR_EMAIL_ADDRESS = "yourGmail@gmail.com"
YOUR_EMAIL_PASSWORD = "yourPassword"

# ********** INFO TO CHANGE **********


